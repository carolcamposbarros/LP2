﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string[,] notasFilme = new string[2,2];
            double nota, media1, media2;

            for (int i = 0; i < notasFilme.GetLength(0); i++) 
            {
                for (int j = 0; j < notasFilme.GetLength(1); j++)
                {
                    notasFilme[i, j] = Interaction.InputBox($"Pessoa: {i + 1} Nota Filme: {j+1}");
                    if (!double.TryParse(notasFilme[i,j], out nota))
                    {
                        MessageBox.Show("Valor invalido!");
                        listBox1.Items.Clear();
                    }
                    else
                    {
                        media1 = (double.Parse(notasFilme[i, 0]) + double.Parse(notasFilme[i, 0])) / 2;
                        media2 = (double.Parse(notasFilme[i, 1]) + double.Parse(notasFilme[i, 1])) / 2;
                        listBox1.Items.Add($"Media Filme 1: {media1} \nMedia Filme 2: {media2}");
                    }
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
