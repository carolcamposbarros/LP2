﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu Copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu Colar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício2>().Count() > 0)
            {
                Application.OpenForms["frmExercício2"].BringToFront();
            }
            else
            {
                frmExercício2 objFrm2 = new frmExercício2();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }
        }
        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                if (Application.OpenForms.OfType<frmExercício3>().Count() > 0)
                {
                    Application.OpenForms["frmExercício3"].BringToFront();
                }
                else
                {
                    frmExercício3 objFrm3 = new frmExercício3();
                    objFrm3.MdiParent = this;
                    objFrm3.WindowState = FormWindowState.Maximized;
                    objFrm3.Show();
                }
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício4>().Count() > 0)
            {
                Application.OpenForms["frmExercício4"].BringToFront();
            }
            else
            {
                frmExercício4 objFrm4 = new frmExercício4();
                objFrm4.MdiParent = this;
                objFrm4.WindowState = FormWindowState.Maximized;
                objFrm4.Show();
            }
        }
    }
}
