﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercício3 : Form
    {
        public frmExercício3()
        {
            InitializeComponent();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            Palavra2.Text = Palavra2.Text.Replace(Palavra1.Text, "");
        }

        private void frmExercício3_Load(object sender, EventArgs e)
        {

        }


        private void btnInverter_Click(object sender, EventArgs e)
        {
            char[] vetor = Palavra1.Text.ToCharArray();
            Array.Reverse(vetor);
            string auxiliar = new string(vetor);
            Palavra2.Text = auxiliar;
        }
    }
}
    
