﻿namespace PMetodos
{
    partial class frmExercício2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.Palavra1 = new System.Windows.Forms.TextBox();
            this.Palavra2 = new System.Windows.Forms.TextBox();
            this.btnComparar = new System.Windows.Forms.Button();
            this.btnInserir1 = new System.Windows.Forms.Button();
            this.btnInserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(232, 153);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(74, 20);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(232, 231);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(74, 20);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // Palavra1
            // 
            this.Palavra1.Location = new System.Drawing.Point(387, 153);
            this.Palavra1.Name = "Palavra1";
            this.Palavra1.Size = new System.Drawing.Size(100, 26);
            this.Palavra1.TabIndex = 2;
            // 
            // Palavra2
            // 
            this.Palavra2.Location = new System.Drawing.Point(387, 231);
            this.Palavra2.Name = "Palavra2";
            this.Palavra2.Size = new System.Drawing.Size(100, 26);
            this.Palavra2.TabIndex = 3;
            // 
            // btnComparar
            // 
            this.btnComparar.Location = new System.Drawing.Point(222, 387);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(143, 84);
            this.btnComparar.TabIndex = 5;
            this.btnComparar.Text = "Comparar Iguais";
            this.btnComparar.UseVisualStyleBackColor = true;
            // 
            // btnInserir1
            // 
            this.btnInserir1.Location = new System.Drawing.Point(463, 387);
            this.btnInserir1.Name = "btnInserir1";
            this.btnInserir1.Size = new System.Drawing.Size(143, 84);
            this.btnInserir1.TabIndex = 6;
            this.btnInserir1.Text = "Inserir 1 no meio do 2";
            this.btnInserir1.UseVisualStyleBackColor = true;
            // 
            // btnInserir2
            // 
            this.btnInserir2.Location = new System.Drawing.Point(694, 387);
            this.btnInserir2.Name = "btnInserir2";
            this.btnInserir2.Size = new System.Drawing.Size(143, 84);
            this.btnInserir2.TabIndex = 7;
            this.btnInserir2.Text = "Inserir ** no meio do 1";
            this.btnInserir2.UseVisualStyleBackColor = true;
            // 
            // frmExercício2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 615);
            this.Controls.Add(this.btnInserir2);
            this.Controls.Add(this.btnInserir1);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.Palavra2);
            this.Controls.Add(this.Palavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercício2";
            this.Text = "frmExercício2";
            this.Load += new System.EventHandler(this.frmExercício2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox Palavra1;
        private System.Windows.Forms.TextBox Palavra2;
        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.Button btnInserir1;
        private System.Windows.Forms.Button btnInserir2;
    }
}