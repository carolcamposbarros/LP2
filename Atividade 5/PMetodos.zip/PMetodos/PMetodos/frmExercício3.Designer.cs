﻿namespace PMetodos
{
    partial class frmExercício3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Palavra2 = new System.Windows.Forms.TextBox();
            this.Palavra1 = new System.Windows.Forms.TextBox();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.btnInverter = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Palavra2
            // 
            this.Palavra2.Location = new System.Drawing.Point(331, 222);
            this.Palavra2.Name = "Palavra2";
            this.Palavra2.Size = new System.Drawing.Size(100, 26);
            this.Palavra2.TabIndex = 7;
            // 
            // Palavra1
            // 
            this.Palavra1.Location = new System.Drawing.Point(331, 144);
            this.Palavra1.Name = "Palavra1";
            this.Palavra1.Size = new System.Drawing.Size(100, 26);
            this.Palavra1.TabIndex = 6;
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(176, 222);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(74, 20);
            this.lblPalavra2.TabIndex = 5;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(176, 144);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(74, 20);
            this.lblPalavra1.TabIndex = 4;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // btnInverter
            // 
            this.btnInverter.Location = new System.Drawing.Point(421, 379);
            this.btnInverter.Name = "btnInverter";
            this.btnInverter.Size = new System.Drawing.Size(143, 84);
            this.btnInverter.TabIndex = 9;
            this.btnInverter.Text = "Inverter o 1";
            this.btnInverter.UseVisualStyleBackColor = true;
            this.btnInverter.Click += new System.EventHandler(this.btnInverter_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(180, 379);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(143, 84);
            this.btnRemove.TabIndex = 8;
            this.btnRemove.Text = "Remover 1 do 2";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // frmExercício3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 612);
            this.Controls.Add(this.btnInverter);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.Palavra2);
            this.Controls.Add(this.Palavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercício3";
            this.Text = "frmExercício3";
            this.Load += new System.EventHandler(this.frmExercício3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Palavra2;
        private System.Windows.Forms.TextBox Palavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Button btnInverter;
        private System.Windows.Forms.Button btnRemove;
    }
}