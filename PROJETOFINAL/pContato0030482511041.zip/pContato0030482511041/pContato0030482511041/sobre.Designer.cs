﻿namespace pContato0030482511041
{
    partial class sobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.picBxRey = new System.Windows.Forms.PictureBox();
            this.picBxJulia = new System.Windows.Forms.PictureBox();
            this.picBxCarol = new System.Windows.Forms.PictureBox();
            this.lblCarol = new System.Windows.Forms.Label();
            this.lblRaCarol = new System.Windows.Forms.Label();
            this.lblJulia = new System.Windows.Forms.Label();
            this.lblRaJulia = new System.Windows.Forms.Label();
            this.lblRey = new System.Windows.Forms.Label();
            this.lblRaRey = new System.Windows.Forms.Label();
            this.lblDev = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBxRey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBxJulia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBxCarol)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(61, 4);
            // 
            // picBxRey
            // 
            this.picBxRey.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBxRey.Image = global::pContato0030482511041.Properties.Resources.rey;
            this.picBxRey.Location = new System.Drawing.Point(629, 129);
            this.picBxRey.Name = "picBxRey";
            this.picBxRey.Size = new System.Drawing.Size(215, 209);
            this.picBxRey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBxRey.TabIndex = 6;
            this.picBxRey.TabStop = false;
            // 
            // picBxJulia
            // 
            this.picBxJulia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBxJulia.Image = global::pContato0030482511041.Properties.Resources.julia;
            this.picBxJulia.Location = new System.Drawing.Point(356, 129);
            this.picBxJulia.Name = "picBxJulia";
            this.picBxJulia.Size = new System.Drawing.Size(203, 209);
            this.picBxJulia.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBxJulia.TabIndex = 5;
            this.picBxJulia.TabStop = false;
            // 
            // picBxCarol
            // 
            this.picBxCarol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBxCarol.Image = global::pContato0030482511041.Properties.Resources.carol;
            this.picBxCarol.Location = new System.Drawing.Point(103, 129);
            this.picBxCarol.Name = "picBxCarol";
            this.picBxCarol.Size = new System.Drawing.Size(185, 209);
            this.picBxCarol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBxCarol.TabIndex = 4;
            this.picBxCarol.TabStop = false;
            // 
            // lblCarol
            // 
            this.lblCarol.AutoSize = true;
            this.lblCarol.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarol.Location = new System.Drawing.Point(109, 341);
            this.lblCarol.Name = "lblCarol";
            this.lblCarol.Size = new System.Drawing.Size(179, 25);
            this.lblCarol.TabIndex = 7;
            this.lblCarol.Text = "Carolina Campos";
            this.lblCarol.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblRaCarol
            // 
            this.lblRaCarol.AutoSize = true;
            this.lblRaCarol.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaCarol.Location = new System.Drawing.Point(121, 366);
            this.lblRaCarol.Name = "lblRaCarol";
            this.lblRaCarol.Size = new System.Drawing.Size(139, 20);
            this.lblRaCarol.TabIndex = 8;
            this.lblRaCarol.Text = "0030482511025";
            this.lblRaCarol.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblJulia
            // 
            this.lblJulia.AutoSize = true;
            this.lblJulia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJulia.Location = new System.Drawing.Point(379, 341);
            this.lblJulia.Name = "lblJulia";
            this.lblJulia.Size = new System.Drawing.Size(166, 25);
            this.lblJulia.TabIndex = 9;
            this.lblJulia.Text = " Júlia Espiñeira ";
            this.lblJulia.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblRaJulia
            // 
            this.lblRaJulia.AutoSize = true;
            this.lblRaJulia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaJulia.Location = new System.Drawing.Point(391, 366);
            this.lblRaJulia.Name = "lblRaJulia";
            this.lblRaJulia.Size = new System.Drawing.Size(139, 20);
            this.lblRaJulia.TabIndex = 10;
            this.lblRaJulia.Text = "0030482511041";
            this.lblRaJulia.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblRey
            // 
            this.lblRey.AutoSize = true;
            this.lblRey.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRey.Location = new System.Drawing.Point(655, 341);
            this.lblRey.Name = "lblRey";
            this.lblRey.Size = new System.Drawing.Size(174, 25);
            this.lblRey.TabIndex = 11;
            this.lblRey.Text = "Reynaldo Ramos";
            this.lblRey.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblRaRey
            // 
            this.lblRaRey.AutoSize = true;
            this.lblRaRey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaRey.Location = new System.Drawing.Point(668, 366);
            this.lblRaRey.Name = "lblRaRey";
            this.lblRaRey.Size = new System.Drawing.Size(139, 20);
            this.lblRaRey.TabIndex = 12;
            this.lblRaRey.Text = "0030482511001";
            this.lblRaRey.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblDev
            // 
            this.lblDev.AutoSize = true;
            this.lblDev.Font = new System.Drawing.Font("PMingLiU-ExtB", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDev.Location = new System.Drawing.Point(141, 64);
            this.lblDev.Name = "lblDev";
            this.lblDev.Size = new System.Drawing.Size(666, 36);
            this.lblDev.TabIndex = 13;
            this.lblDev.Text = "ESSE PROJETO FOI DESENVOLVIDO POR:";
            // 
            // sobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 478);
            this.Controls.Add(this.lblDev);
            this.Controls.Add(this.lblRaRey);
            this.Controls.Add(this.lblRey);
            this.Controls.Add(this.lblRaJulia);
            this.Controls.Add(this.lblJulia);
            this.Controls.Add(this.lblRaCarol);
            this.Controls.Add(this.lblCarol);
            this.Controls.Add(this.picBxRey);
            this.Controls.Add(this.picBxJulia);
            this.Controls.Add(this.picBxCarol);
            this.Name = "sobre";
            this.Text = "sobre";
            ((System.ComponentModel.ISupportInitialize)(this.picBxRey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBxJulia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBxCarol)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.PictureBox picBxCarol;
        private System.Windows.Forms.PictureBox picBxJulia;
        private System.Windows.Forms.PictureBox picBxRey;
        private System.Windows.Forms.Label lblCarol;
        private System.Windows.Forms.Label lblRaCarol;
        private System.Windows.Forms.Label lblJulia;
        private System.Windows.Forms.Label lblRaJulia;
        private System.Windows.Forms.Label lblRey;
        private System.Windows.Forms.Label lblRaRey;
        private System.Windows.Forms.Label lblDev;
    }
}