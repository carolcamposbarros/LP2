﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace pContato0030482511041
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;// conexao com bd
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=APOLO;Initial Catalog=BD;Persist Security Info=True;User ID=BD2511041;Password=271110*Lala");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros erros =/" + ex.Message);
            }
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                //MessageBox.Show("Form ja existe");
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato objC = new frmContato();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Você tem certeza que quer sair?", "Sair",MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                Close();
            }
            else 
            {
                MessageBox.Show("Tem certeza que quer cancelar?", "Cancelar", MessageBoxButtons.OKCancel);
                if (result == DialogResult.Cancel)
                {
                    Close();
                }
                
            }

        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<sobre>().Count() > 0)
            {
                //MessageBox.Show("Form ja existe");
                Application.OpenForms["sobre"].BringToFront();
            }
            else
            {
                sobre objC = new sobre();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }
    }
}
