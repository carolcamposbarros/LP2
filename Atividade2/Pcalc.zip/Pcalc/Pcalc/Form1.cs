﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtNumero2, "Numero 2 invalido");
                txtNumero2.Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado=numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btbSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero1 == 0) {
                MessageBox.Show("O numero informado nao pode ser zero");
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }
private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            txtResultado.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair mesmo?",
                                 "Saida", MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Question) ==
                                DialogResult.Yes)
                {
                Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
                {

                }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, " Numero 1 invalido");
                txtNumero1.Focus();
           }
        }
    }
}
